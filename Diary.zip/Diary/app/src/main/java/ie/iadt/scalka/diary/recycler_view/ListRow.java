package ie.iadt.scalka.diary.recycler_view;


import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;

class ListRow extends RecyclerView.ViewHolder {
    public ImageView mThumbnail;

    public ListRow(View itemView) {
        super(itemView);
    }
}
